package net.sf.JRecord.Types;

public interface ISizeInformation {

	/**
	 * Gets the normal size of a type (in bytes)
	 * @return
	 */
	public int getNormalSize();
}
