package net.sf.JRecord.CsvParser;

public interface ICharIterator {

	public boolean hasNext();

	public char get();
}
