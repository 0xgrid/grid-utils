package net.sf.JRecord.Common;

public interface IEmptyTest {

	public abstract boolean isEmpty();
}
