/*
 * @Author Bruce Martin
 * Created on 7/02/2007
 *
 * Purpose:
 * Demonstrate writing a CopybookLoader (ie a class to read
 * a record layout or Copybook from an external file).
 */
package net.sf.JRecord.External;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.xml.parsers.ParserConfigurationException;

import net.sf.JRecord.Common.Constants;
import net.sf.JRecord.Common.Conversion;
import net.sf.JRecord.Common.RecordException;
import net.sf.JRecord.CsvParser.BasicCsvLineParser;
import net.sf.JRecord.CsvParser.CsvDefinition;
import net.sf.JRecord.External.Def.ExternalField;
import net.sf.JRecord.ExternalRecordSelection.ExternalFieldSelection;
import net.sf.JRecord.Log.AbsSSLogger;
import net.sf.JRecord.Numeric.Convert;
import net.sf.JRecord.Types.Type;

import org.xml.sax.SAXException;

/**
 * This class reads a Record Layout (Copybook) stored in a  tab delimited file.
 * Fields in the file are<ol>
 * <li>Starting Position
 * <li>Length
 * <li>Number of places after the decimal point
 * <li>Field Name
 * <li>Field Type (String [or char], num, mainframe_zoned, fuji_zoned)
 * <li>Decimal - number of places after the decimal point
 * <li>Format Field Format (used in the Record Editor)
 * <li>Parameter - parameter for the Type / Format
 * </ol>
 *
 * <pre>
 *   <b>Usage:</b>
 *        CopybookLoader loader = new RecordEditorCsvLoader(",");
 *        LayoutDetail layout = loader.loadCopyBook(copybookName, 0, 0, "", 0, 0, null).asLayoutDetail();
 * </pre>
 *
 * @author Bruce Martin
 *
 */
public class RecordEditorCsvLoader implements CopybookLoader {

    //private static HashMap typeConv = new HashMap();


    private final String delimiter;

    public RecordEditorCsvLoader(String fieldSeperator) {
    	//TypeList
    	delimiter = fieldSeperator;

    }

    /**
     * load a copybook
     */
    public ExternalRecord loadCopyBook(String copyBookFile,
            int splitCopybookOption, int dbIdx, String font, int binFormat,
            int systemId, AbsSSLogger log) throws IOException, SAXException,
            ParserConfigurationException, RecordException {

        int rt = Constants.rtRecordLayout;
        if (binFormat == Convert.FMT_MAINFRAME) {
            rt = Constants.rtBinaryRecord;
        }

        ExternalRecord rec = ExternalRecord.getNullRecord(
        		Conversion.getCopyBookId(copyBookFile),
                rt,
                font);
        rec.setNew(true);

        insertFields(log, rec, copyBookFile, dbIdx);

        return rec;
    }

    /**
     * Add fields to the copybook
     * @param rec copybook
     * @param copyBookFile copybook file
     */
    private final void insertFields(AbsSSLogger log, ExternalRecord rec, String copyBookFile, int dbIdx) {
        try {
        	insertFields(log, rec, new FileReader(copyBookFile), copyBookFile, dbIdx);
        } catch (Exception e) {
            System.out.println("Error Opening file "
                    + copyBookFile
                    + ": " + e.getMessage());
            e.printStackTrace();
            log.logMsg(AbsSSLogger.SHOW, "Error Loading Copybook: " + e.getMessage());
            log.logException(AbsSSLogger.SHOW, e);
        }
    }

    public final void insertFields(AbsSSLogger log, ExternalRecord rec,
    		InputStreamReader  in, String layoutName, int dbIdx) {

        String s, name, typeStr, description, formatStr, param;
        String directory = null;
        BasicCsvLineParser t = BasicCsvLineParser.getInstance();
        String[] fields = new String[8];
        ExternalRecord sr;
        ExternalField field;
        int pos, len, decimal, type, j, format;
        int idx = 0;
        int i = 1;
        int inputLine = 1;
        try {
            BufferedReader r = new BufferedReader(in);
            while ((s = r.readLine()) != null) {
                if (!s.trim().startsWith("#")) {
                    //t = new StringTokenizer(s, seperator);

                	for (j = 0; j < fields.length; j++) {
                		fields[j] = t.getField(j, s, new CsvDefinition(delimiter, null));
             //   		System.out.print("\t" + fields[j]);
                		if (fields[j] == null) {
                			fields[j] = "";
                			break;
                		}
                	}

                	idx = 1;

                    try {
                     	if (Constants.RECORD_NAME.equalsIgnoreCase(fields[0])) {
	                    	rec.setFileStructure(ExternalConversion.getFileStructure(dbIdx, fields[idx++]));
	                    	rec.setRecordType(ExternalConversion.getRecordType(dbIdx, fields[idx++]));
	                    	rec.setDelimiter(fields[idx++]);
	                    	rec.setRecordStyle(ExternalConversion.getRecordStyle(dbIdx, fields[idx++]));
	                    	rec.setQuote(fields[idx++]);
	                    	rec.setListChar(fields[idx++]);
	                    	rec.setDescription(fixDescription(fields[idx++]));
                    	} else if (Constants.SUB_RECORD_NAME.equalsIgnoreCase(fields[0])) {
                    		sr = ExternalRecord.getNullRecord(fields[idx++], "");
                    		try {
                    			ExternalFieldSelection f = new ExternalFieldSelection();
                    			f.setFieldName(fields[idx++]);
                    			f.setFieldValue(fields[idx++]);
	                    		sr.setRecordSelection(f);

	                       		sr.setParentRecord(Integer.parseInt(fields[idx++]));
	                    	} catch (Exception e) {
                    			log.logMsg(AbsSSLogger.SHOW, "Error File: " + layoutName
                    					+ " line " + inputLine + " Field Number: " + idx
    	                                + " : " + e.getMessage());
							}
                       		rec.addRecord(sr);

                       		if (directory == null) {
                       			directory = getDirectory(layoutName);
                       			System.out.println("Directory: >" + directory + "<");
                       		}

                       		System.out.println("File >" + directory + fields[1] + Constants.TXT_EXTENSION);
                       		insertFields(log, sr, directory + fields[1] + Constants.TXT_EXTENSION, dbIdx);
                       	} else {
                    		idx = 0;
	                        pos  = Integer.parseInt(fields[idx++]);
	                        //System.out.println(fields[0] + " ! " + fields[1]);
	                        len  = Integer.parseInt(fields[idx++]);
	                        name = fields[idx++];
	                        description = fixDescription(fields[idx++]);
	                        typeStr = fields[idx++];

	                        decimal = 0;
	                        try {
	                        	decimal = Integer.parseInt(fields[idx]);
	                        } catch (Exception e) {	}
	                        idx += 1;
	                        formatStr = fields[idx++];
	                        param     = fields[idx++];

	                        type = Type.ftChar;
	                        if (typeStr != null && ! "".equals(typeStr)) {
	                            typeStr = typeStr.toLowerCase();
	                            type = ExternalConversion.getType(dbIdx, typeStr);
	                        }
	                        format = 0;
	                        if (formatStr != null && ! "".equals(typeStr)) {
	                        	formatStr = formatStr.toLowerCase();
	                            format =ExternalConversion.getFormat(dbIdx, formatStr);
	                        }


	                        //System.out.println("\t Type: " + type);

	                        field = new ExternalField(pos, len, name, description, type,
	                                decimal, format, param, "", "", i);
	                        rec.addRecordField(field);
	                        i += 1;
                    	}
	                } catch (Exception e) {
	                    log.logMsg(AbsSSLogger.SHOW, "Error File: " + layoutName
	                    			+ " Adding line " + inputLine + " Field Number: " + idx
	                                + " : " + e.getMessage());
	                    e.printStackTrace();
	                }

                    inputLine += 1;
                }
            }
        } catch (Exception e) {
            System.out.println("Error Adding line " + inputLine
                    + " from file " + layoutName
                    + ": " + e.getMessage());
            e.printStackTrace();
            log.logMsg(AbsSSLogger.SHOW, "Error Loading Copybook: " + e.getMessage());
            log.logException(AbsSSLogger.SHOW, e);
        }
    }



    private static String getDirectory(String fileName) {
    	int e = Math.max(
    			fileName.lastIndexOf('/'),
    			fileName.lastIndexOf('\\'));

    	if (e > 0) {
    		e += 1;
    	}
    	return fileName.substring(0, e);
    }


	/**
	 * Fix up carriage returns
	 * @param description input description
	 * @return description with \n's replaced
	 */
	private String fixDescription(String description) {

		if (description == null || description.indexOf('\n') == 0) {
			return description;
		}
		StringBuilder b = new StringBuilder(description);

		Conversion.replace(b,  "\\n", "\n");
		return b.toString();
	}



    /**
     * CSV Parser - Tab
     * @author Bruce Martin
     */
    public static final class Tab extends RecordEditorCsvLoader {
    	public Tab() {
    		super("\t");
    	}
    }


    /**
     * CSV Parser - Tab
     * @author Bruce Martin
     */
    public static final class Comma extends RecordEditorCsvLoader {
    	public Comma() {
    		super(",");
    	}
    }
}
